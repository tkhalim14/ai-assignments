______________________________________________________________________________________________
----------------------------------------------------------------------------------------------

-->> A.I Assignment-3 :
     
    (Team - 14)

    ->> Input Format :

        No. of Variables
  		No. of clauses
		Beam Width
		Tabu Tenure

    ->> Example :
        10
		100
		10
		6


    ->> Output Format :
        
    ->> Example :
        no of clauses= 100
        no of variables=10
        the initial guess=0101101000 
        its heuristic= 86


        VND
        circit is not satisfiable.
        Goal State=-
        No of states explored= 14


        BEAM SEARCH with width=10 
        stuck in a local maxima, couldn't find the solution
        Goal state= -
        No of states explored= 55 


        TABU SEARCH with tenure=6
        stuck in a local maxima, couldn't find the solution
        Goal state= -
        No of states explored= 59
______________________________________________________________________________________________
----------------------------------------------------------------------------------------------













