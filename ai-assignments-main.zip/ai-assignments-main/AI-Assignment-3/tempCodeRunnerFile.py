fout.write(f"\n\n\nBEAM SEARCH with width={beam_width} \n")
# print(f"\n\n\nBEAM SEARCH with width={beam_width} \n")
# start_time=time.time()
# beam_search(formu,[input_variables],beamwidth=beam_width)
# print("--- %s seconds ---" % (time.time() - start_time))
# exitrec=0