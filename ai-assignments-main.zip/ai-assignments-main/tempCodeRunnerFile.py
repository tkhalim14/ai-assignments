    # for neighbour in templist: 
    #     if neighbour not in open_list:
    #         open_list.add(neighbour)