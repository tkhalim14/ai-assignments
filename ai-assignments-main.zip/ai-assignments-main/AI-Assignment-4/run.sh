#!/bin/bash
python3 14.py $1 > output.txt
